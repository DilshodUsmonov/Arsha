const elbutton=document.querySelector('.buttonn');
const elheader=document.querySelector('header');
elbutton.addEventListener('click', (e)=> {
elheader.classList.toggle('scrol')
})